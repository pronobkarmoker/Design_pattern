package BSSE1431_Lab06.Proxy;

public interface Image {
    void display();
}
