package Miscellaneous;

public interface LibraryItem {
    String getDetails();
    boolean borrowItem();
}
