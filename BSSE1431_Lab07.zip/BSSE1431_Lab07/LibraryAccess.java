package Miscellaneous;

public interface LibraryAccess {
    boolean accessItem(String itemID, User user);
}
