package FactoryMethod;

abstract class Creator {
    public abstract Product createProduct(Object... attributes);
}
