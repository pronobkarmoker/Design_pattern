package AbstractFactory;

public interface Sofa {
    public void display();
}