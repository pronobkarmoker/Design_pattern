package AbstractFactory;

public class ModernSofa implements Sofa{
    @Override
    public void display() {
        System.out.println("Modern Sofa");
    }
}
