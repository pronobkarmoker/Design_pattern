package AbstractFactory;

public class VictorianChair implements Chair{
    @Override
    public void display() {
        System.out.println("Victorian Chair");
    }
}

