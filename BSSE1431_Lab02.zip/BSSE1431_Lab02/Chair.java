package AbstractFactory;

public interface Chair {
	public void display();
}
