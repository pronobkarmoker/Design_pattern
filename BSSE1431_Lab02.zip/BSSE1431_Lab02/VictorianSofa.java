package AbstractFactory;

public class VictorianSofa implements Sofa {
    @Override
    public void display() {
        System.out.println("Victorian Sofa");
    }
}

