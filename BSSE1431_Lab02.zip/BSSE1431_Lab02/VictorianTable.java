package AbstractFactory;

public class VictorianTable implements Table{
    @Override
    public void display() {
        System.out.println("Victorian Table");
    }
}
