package AbstractFactory;

public interface Table {
	public void display();
}
